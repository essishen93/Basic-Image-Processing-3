//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 3 : (a)
//This code is to shrinking the binary image
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
#include "function.h"
using namespace std;

const int Size_H=108;    //the size of input image
const int Size_W=91;    //the size of input image


int get_M(int bone, int value);  //get M Array after the first stage
int get_G(int value);            //get G Array after the sencond stage

int  main()
{
   
    int pO=0,qO=0;    //the Image coordinate of output
    int pI=0,qI=0;    //the Image coordinate of input
    
    unsigned char CIn_Image  [Size_H][Size_W];         //the image data of input image
    unsigned char In_Image   [Size_H][Size_W];         //the image data of input image(0-1)
    unsigned char M_Array    [Size_H][Size_W]={0};     //M Array
    unsigned char G_Array    [Size_H][Size_W]={0};     //G Array
    unsigned char Label      [Size_H][Size_W]={0};     //the label of object in the first step
    unsigned char Out_Image [Size_H][Size_W]={0};      //the image data of output image after shrinking
    unsigned char color_Image[Size_H][Size_W][3]={0};  //the image data of output image with object labeled by color

    
    
    ///////////////Read image///////////////
    ifstream ifile("Horseshoe.raw",ios_base::in | ios_base::binary);
    if (!ifile)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            ifile.read((char*)&CIn_Image[pI][qI],sizeof(CIn_Image[pI][qI]));
            if (CIn_Image[pI][qI]==255)
                In_Image[pI][qI]=1;
            else
                In_Image[pI][qI]=0;
        }
    ifile.close();
    
    int hole=0;       //the number of holes
    int hole_nghb=0;  //the total value of neighbors of possible holes
    int h,k;
    //////////////How many holes////////////////
    for (pI=1;pI<Size_H-1;pI++)
        for (qI=1;qI<Size_W-1;qI++)
        {
            if (In_Image[pI][qI]==0)  //possibel holes
            {
                hole_nghb=0;
                for (h=-1;h<2;h++)
                    for (k=-1;k<2;k++)
                        hole_nghb+=In_Image[pI+h][qI+k];
                if (hole_nghb==8)     //if all its neighbors are 1, it is a hole.
                    hole++;
            }
        }
    cout<<"The number of holes in the image is "<<hole<<endl;
    
    int bone=0;
    int side_conn=0;
    int corn_conn=0;
    int value=0;
    int times=1;int i=0; //the times of iteration
    
    //////////////Shrinking////////////////
    while (times)
    {
        i++;
        //initial M array and G array
        for (pI=0;pI<Size_H;pI++)
            for (qI=0;qI<Size_W;qI++)
            {
                M_Array[pI][qI]=0;
                G_Array[pI][qI]=0;
            }
    for (pI=1;pI<Size_H-1;pI++)
        for (qI=1;qI<Size_W-1;qI++)
        {
            if (In_Image[pI][qI]==1)
            {
                //coding every 3x3 window to binary number (0-255)
                value=In_Image[pI][qI+1]+
                (int)pow(2,1)*In_Image[pI-1][qI+1]+
                (int)pow(2,2)*In_Image[pI-1][qI]+
                (int)pow(2,3)*In_Image[pI-1][qI-1]+
                (int)pow(2,4)*In_Image[pI][qI-1]+
                (int)pow(2,5)*In_Image[pI+1][qI-1]+
                (int)pow(2,6)*In_Image[pI+1][qI]+
                (int)pow(2,7)*In_Image[pI+1][qI+1];
               
                //compute the bone
                side_conn=In_Image[pI][qI-1]+In_Image[pI][qI+1]+In_Image[pI-1][qI]+In_Image[pI+1][qI];
                corn_conn=In_Image[pI-1][qI-1]+In_Image[pI-1][qI+1]+In_Image[pI+1][qI-1]+In_Image[pI+1][qI+1];
                bone=2*side_conn+corn_conn;
                
                //obtain the M_array, find the candidate for removal
                M_Array[pI][qI]=get_M(bone,value);
               
            }
        }
    
    for (pI=1;pI<Size_H-1;pI++)
        for (qI=1;qI<Size_W-1;qI++)
        {
            if (M_Array[pI][qI]==1)
            {
                //coding every 3x3 window to binary number (0-255)
                value=M_Array[pI][qI+1]+
                (int)pow(2,1)*M_Array[pI-1][qI+1]+
                (int)pow(2,2)*M_Array[pI-1][qI]+
                (int)pow(2,3)*M_Array[pI-1][qI-1]+
                (int)pow(2,4)*M_Array[pI][qI-1]+
                (int)pow(2,5)*M_Array[pI+1][qI-1]+
                (int)pow(2,6)*M_Array[pI+1][qI]+
                (int)pow(2,7)*M_Array[pI+1][qI+1];
                
                //obtain the G_array, find the candidate for not removal
                G_Array[pI][qI]=get_G(value);
                
            
            }
        }
    
    //get the final points for removal
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
        {
            if (G_Array[pO][qO]==1)
                M_Array[pO][qO]=0;
            else
                M_Array[pO][qO]=M_Array[pO][qO];
        }
        times=0;
        for (pO=0;pO<Size_H;pO++)
            for (qO=0;qO<Size_W;qO++)
            {
                if (M_Array[pO][qO]==1)
                {
                    In_Image[pO][qO]=0;
                    times=1;
                }
                else
                    In_Image[pO][qO]=In_Image[pO][qO];
            }
        //if (times==0)
            //cout<<"The times of iteration is "<<i<<endl;
    }
    
    int nail=0;       //the number of holes
    int nail_nghb=0;  //the total value of neighbors of possible holes
    //////////////How many nails////////////////
    for (pI=1;pI<Size_H-1;pI++)
        for (qI=1;qI<Size_W-1;qI++)
        {
            if (In_Image[pI][qI]==1)  //possibel nails
            {
                nail_nghb=0;
                for (h=-1;h<2;h++)
                    for (k=-1;k<2;k++)
                        nail_nghb+=In_Image[pI+h][qI+k];
                if (nail_nghb==1)     //if all its neighbors are 1, it is a hole.
                    nail++;
            }
        }
    cout<<"The number of nails in the image is "<<nail<<endl;


    ///////////////////Write image/////////////////////
    ofstream ofile("Horseshoe_S.raw",ios_base::out | ios_base::binary);
    if (!ofile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
            {
            
                if (In_Image[pO][qO]==1)
                    Out_Image[pO][qO]=255;
                else
                    Out_Image[pO][qO]=0;
               
                    
                Out_Image[pO][qO]=Out_Image[pO][qO]+0x00;    //Convert to hex or bin
                ofile.write((char*)&Out_Image[pO][qO],sizeof(Out_Image[pO][qO]));
            }
    ofile.close();
  
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            if (CIn_Image[pI][qI]==255)
                In_Image[pI][qI]=1;
            else
                In_Image[pI][qI]=0;
        }
    
    In_Image[7][36]=1;
    In_Image[9][45]=1;
    In_Image[8][52]=1;
    
    ///////////////Object Detection////////////////
    int neigh_value=0;     //checking the labels of neighbors
    int label=1;
    int min=0,temp=0;
    int link[30][30]={0};  //the label table
    int link_min[30]={0};  //the minimum label each label connects
    int j=0;
    for (pI=1;pI<Size_H-1;pI++)
        for (qI=1;qI<Size_W-1;qI++)
        {
            //non-background
            if (In_Image[pI][qI]==1)
            {
                neigh_value=In_Image[pI][qI-1]+In_Image[pI-1][qI-1]+In_Image[pI-1][qI]+In_Image[pI-1][qI+1];
                //surround by background
                if (neigh_value==0)
                {
                    Label[pI][qI]=label;
                    label++;
                }
                else
                {
                    //find the minimum label surrounded
                    if (Label[pI][qI-1]!=0)
                    min=Label[pI][qI-1];
                    if (Label[pI-1][qI-1]!=0)
                    min=Label[pI-1][qI-1];
                    if (Label[pI-1][qI]!=0)
                    min=Label[pI-1][qI];
                    if (Label[pI-1][qI+1]!=0)
                    min=Label[pI-1][qI+1];
                    
                    if  (Label[pI][qI-1]!=0)
                    {
                    temp=Label[pI][qI-1];
                        if (temp<min)
                            min=temp;
                    }
                    if  (Label[pI-1][qI-1]!=0)
                    {
                    temp=Label[pI-1][qI-1];
                        if (temp<min)
                            min=temp;
                    }
                    if  (Label[pI-1][qI]!=0)
                    {
                    temp=Label[pI-1][qI];
                        if (temp<min)
                            min=temp;
                    }
                    if  (Label[pI-1][qI+1]!=0)
                    {
                    temp=Label[pI-1][qI+1];
                        if (temp<min)
                            min=temp;
                    }
                    //minimum
                    Label[pI][qI]=min;
                    
                    //update the label tabel
                    if  (Label[pI][qI-1]!=0)
                    {
                        temp=Label[pI][qI-1];
                        link[min][temp]=1;
                        link[temp][min]=1;
                        
                    }
                    if  (Label[pI-1][qI-1]!=0)
                    {
                        temp=Label[pI-1][qI-1];
                        link[min][temp]=1;
                        link[temp][min]=1;
                    }
                    if  (Label[pI-1][qI]!=0)
                    {
                        temp=Label[pI-1][qI];
                        link[min][temp]=1;
                        link[temp][min]=1;
                    }
                    if  (Label[pI-1][qI+1]!=0)
                    {
                        temp=Label[pI-1][qI+1];
                        link[min][temp]=1;
                        link[temp][min]=1;
                    }
                
                
                }
            }
            
        }
    
    
    
    //complete the label table
    for (pI=0;pI<30;pI++)
        for (qI=0;qI<30;qI++)
        {
            if (link[pI][qI]!=0)
            {
                for (j=0;j<30;j++)
                {
                    if (link[qI][j]!=0)
                    {
                        link[j][pI]=1;
                        link[pI][j]=1;
                    }
                }
            
            }
        }
    
   
    int obj=0;
    //find the minimum label each label connects
    for (pI=0;pI<30;pI++)
        for (qI=0;qI<30;)
        {
            if (link[pI][qI]!=0)
            {
                link_min[pI]=qI;
                if (qI!=1)
                    obj++;
                qI=30;
            }
            else
                qI++;
        }
    cout<<"The number of objects in the image is "<<obj<<endl;
    
    //label the object by different colors
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
        {
            if (link_min[Label[pO][qO]]==1)
            {
                color_Image[pO][qO][0]=255;
                color_Image[pO][qO][1]=255;
                color_Image[pO][qO][2]=255;
            }
            else if (link_min[Label[pO][qO]]==10)
            {
                color_Image[pO][qO][0]=0;
                color_Image[pO][qO][1]=255;
                color_Image[pO][qO][2]=0;
            }
            else if (link_min[Label[pO][qO]]==11)
            {
                color_Image[pO][qO][0]=0;
                color_Image[pO][qO][1]=0;
                color_Image[pO][qO][2]=255;
            }
            else if (link_min[Label[pO][qO]]==18)
            {
                color_Image[pO][qO][0]=255;
                color_Image[pO][qO][1]=255;
                color_Image[pO][qO][2]=0;
            }
            else if (link_min[Label[pO][qO]]==19)
            {
                color_Image[pO][qO][0]=255;
                color_Image[pO][qO][1]=0;
                color_Image[pO][qO][2]=255;
            }
            else if (link_min[Label[pO][qO]]==20)
            {
                color_Image[pO][qO][0]=0;
                color_Image[pO][qO][1]=255;
                color_Image[pO][qO][2]=255;
            }
            else if (link_min[Label[pO][qO]]==21)
            {
                color_Image[pO][qO][0]=255;
                color_Image[pO][qO][1]=0;
                color_Image[pO][qO][2]=0;
            }
            else
            {
                color_Image[pO][qO][0]=0;
                color_Image[pO][qO][1]=0;
                color_Image[pO][qO][2]=0;
            }
        }
    

     ///////////////////Write image/////////////////////
    int c=0;
    ofstream cfile("Horseshoe_object.raw",ios_base::out | ios_base::binary);
    if (!cfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
            for (c=0;c<3;c++)
            {
          
                color_Image[pO][qO][c]=color_Image[pO][qO][c]+0x00;    //Convert to hex or bin
                cfile.write((char*)&color_Image[pO][qO][c],sizeof(color_Image[pO][qO][c]));
            
            }
            
    
    cfile.close();
    
    cout<<"The end!"<<endl;
    getchar();
    return 0;
}
