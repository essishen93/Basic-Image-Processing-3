//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (a)
//This code is to implement digital halftoning by dithering
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

const int Size_H=512;    //the size of input image
const int Size_W=512;    //the size of input image
const int R_4=4;         //the size of Bayer index matrix
const int R_8=8;         //the size of Bayer index matrix

int  main()
{
    
    int pO=0,qO=0;    //the Image coordinate of output
    int pI=0,qI=0;    //the Image coordinate of input
    int i=0,j=0;
    int i_4=0,j_4=0;
    int i_8=0,j_8=0;
    
    unsigned char In_Image   [Size_H][Size_W];               //the image data of input image
    double        Nm_Image   [Size_H][Size_W];               //the input image with the normalized gray value (0-1)
    unsigned char Out_Image4 [Size_H][Size_W];               //the image data of output image by 4X4 Bayer matrix
    unsigned char Out_Image8 [Size_H][Size_W];               //the image data of output image by 8X8 Bayer matrix
    unsigned char Out_Image  [Size_H][Size_W];               //the image data of output image by 4 gray value(0,85,170,255)
    unsigned char Processd   [Size_H][Size_W]={0};           //the image data that has already been processed or not
    
    
    //the Bayer matrix and the threshold matrix
    int Bayer_4[R_4][R_4]={{ 5, 9, 6,10},
                           {13, 1,14, 2},
                           { 7,11, 4, 8},
                           {15, 3,12, 0}};
    int Bayer_8[R_8][R_8]={{21,37,25,41,22,38,26,42},
                           {53, 5,57, 9,54, 6,58,10},
                           {29,45,17,33,30,46,18,34},
                           {61,13,49, 1,62,14,50, 2},
                           {23,39,27,43,20,36,24,40},
                           {55, 7,59,11,52, 4,56, 8},
                           {31,47,19,35,28,44,16,32},
                           {63,15,51, 3,60,12,48, 0}};
    double T_4[R_4][R_4]={0};
    double T_8[R_8][R_8]={0};
    for (i=0;i<R_4;i++)
        for (j=0;j<R_4;j++)
            T_4[i][j]=(Bayer_4[i][j]+0.5)/(R_4*R_4);
  
    
    for (i=0;i<R_8;i++)
        for (j=0;j<R_8;j++)
            T_8[i][j]=(Bayer_8[i][j]+0.5)/(R_8*R_8);
    
    ///////////////Read image///////////////
    ifstream ifile("mandrill.raw",ios_base::in | ios_base::binary);
    if (!ifile)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            ifile.read((char*)&In_Image[pI][qI],sizeof(In_Image[pI][qI]));
    
    ////////////Dithering//////////////////
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            pO=pI;qO=qI;
            //Normalization
            Nm_Image[pI][qI]=(double)In_Image[pI][qI]/256;
            
            //Find the thresholds in the matrix
            i_4=(int)pI%R_4;j_4=(int)qI%R_4;
            i_8=(int)pI%R_8;j_8=(int)qI%R_8;
            
            //threshold
            if (Nm_Image[pI][qI]>T_4[i_4][j_4])
                Out_Image4[pO][qO]=255;
            else
                Out_Image4[pO][qO]=0;
            
            if (Nm_Image[pI][qI]>T_8[i_8][j_8])
                Out_Image8[pO][qO]=255;
            else
                Out_Image8[pO][qO]=0;
            
            if (Nm_Image[pI][qI]>0.5)
                Processd[pI][qI]=1;
            else
                Processd[pI][qI]=0;
        }
   
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            pO=pI;qO=qI;
            //Find the thresholds in the matrix
            //i_4=(int)pI%R_4;j_4=(int)qI%R_4;
            i_8=(int)pI%R_8;j_8=(int)qI%R_8;
            if (Out_Image4[pO][qO]==0)
            {
                if (Nm_Image[pI][qI]>T_4[i_8][j_8])
                    Out_Image[pO][qO]=85;
                else
                    Out_Image[pO][qO]=0;
                
            
            }
            else
            {
                if (Nm_Image[pI][qI]>T_4[i_8][j_8])
                    Out_Image[pO][qO]=255;
                else
                    Out_Image[pO][qO]=170;
                
                
            }
            
        }
    
    ///////////////////Write image/////////////////////
    ofstream ofile_4("mandrill_4.raw",ios_base::out | ios_base::binary);
    if (!ofile_4)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    ofstream ofile_8("mandrill_8.raw",ios_base::out | ios_base::binary);
    if (!ofile_8)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    ofstream ofile("mandrill_mul.raw",ios_base::out | ios_base::binary);
    if (!ofile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
        {
            Out_Image4[pO][qO]=Out_Image4[pO][qO]+0x00;    //Convert to hex or bin
            ofile_4.write((char*)&Out_Image4[pO][qO],sizeof(Out_Image4[pO][qO]));
            
            Out_Image8[pO][qO]=Out_Image8[pO][qO]+0x00;    //Convert to hex or bin
            ofile_8.write((char*)&Out_Image8[pO][qO],sizeof(Out_Image8[pO][qO]));
            
            Out_Image[pO][qO]=Out_Image[pO][qO]+0x00;    //Convert to hex or bin
            ofile.write((char*)&Out_Image[pO][qO],sizeof(Out_Image[pO][qO]));
        }
    
    
    ifile.close();
    ofile_4.close();
    ofile_8.close();
    ofile.close();
    cout<<"The end!"<<endl;
    getchar();
    return 0;
}
