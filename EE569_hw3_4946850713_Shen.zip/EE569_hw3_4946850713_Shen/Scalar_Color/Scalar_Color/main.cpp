//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (c)
//This code is to implement scalar color halftoning
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

const int Size_H=512;        //the size of input image
const int Size_W=512;        //the size of input image
const int BytesPerPixel=3;   //24-bit
const double T=0.5;          //threshold

int  main()
{
    int c=0;          //channels
    int pO=0,qO=0;    //the Image coordinate of output
    int pI=0,qI=0;    //the Image coordinate of input
    
    unsigned char In_Image   [Size_H][Size_W][BytesPerPixel];               //the image data of input image
    double        Nm_Image   [Size_H][Size_W][BytesPerPixel];               //the input image with the normalized gray value (0-1)
    unsigned char Out_Image  [Size_H][Size_W][BytesPerPixel];               //the image data of output image by 4X4 Bayer matrix
    
    
    ///////////////Read image///////////////
    ifstream ifile("Sailboat.raw",ios_base::in | ios_base::binary);
    if (!ifile)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
                ifile.read((char*)&In_Image[pI][qI][c],sizeof(In_Image[pI][qI][c]));
    
    ////////////Normalization//////////////////
    //Normalization
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
                Nm_Image[pI][qI][c]=1.0-(double)In_Image[pI][qI][c]/256;
            
    
    double new_value=0;
    double error=0;
    ///////Floyd-Steinberg's error diffusion///////////
    for (c=0;c<BytesPerPixel;c++)
        for (pI=0;pI<Size_H;pI++)
        {
            //the even row
            if (pI%2==0)
            {
                for (qI=0;qI<Size_W;qI++)
                {
                    pO=pI;qO=qI;
                    if(Nm_Image[pI][qI][c]>T)
                    {
                        Out_Image[pO][qO][c]=0;
                        new_value=1;
                    }
                    else
                    {
                        Out_Image[pO][qO][c]=255;
                        new_value=0;
                    }
                    error=Nm_Image[pI][qI][c]-new_value;
                //if (Nm_Image[pI][qI][c]<0)
                    //cout<<"-1"<<endl;
                
                //Floyd-Steinberg's error diffusion
                if (qI==0)
                {
                    Nm_Image[pI]  [qI+1][c]=Nm_Image[pI]  [qI+1][c]+error*7/16;
                    
                    Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error*5/16;
                    Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error*1/16;
                }
                else if (qI==Size_W-1)
                {
                    Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error*5/16;
                    Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error*3/16;
                }
                else
                {
                    Nm_Image[pI]  [qI+1][c]=Nm_Image[pI]  [qI+1][c]+error*7/16;
                    Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error*3/16;
                    Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error*5/16;
                    Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error*1/16;
                    
                }
                }
            }
        
        //the odd row
        else
        {
            for (qI=Size_W-1;qI>=0;qI--)
            {
                pO=pI;qO=qI;
                if(Nm_Image[pI][qI][c]>T)
                {
                    Out_Image[pO][qO][c]=0;
                    new_value=1;
                }
                else
                {
                    Out_Image[pO][qO][c]=255;
                    new_value=0;
                }
                error=Nm_Image[pI][qI][c]-new_value;
                
                //Floyd-Steinberg's error diffusion
                if (pI<Size_H-1 && qI==Size_W-1)
                {
                    Nm_Image[pI]  [qI-1][c]=Nm_Image[pI]  [qI-1][c]+error*7/16;
                    
                    Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error*5/16;
                    Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error*1/16;
                }
                else if (pI<Size_H-1 && qI==0)
                {
                    Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error*5/16;
                    Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error*3/16;
                }
                else if (pI==Size_H-1 && qI!=0)
                {
                    Nm_Image[pI]  [qI-1][c]=Nm_Image[pI]  [qI-1][c]+error*7/16;
                }
                else if (pI==Size_H-1 && qI==0)
                {
                    Nm_Image[pI][qI][c]=Nm_Image[pI][qI][c];
                }
                else
                {
                    Nm_Image[pI]  [qI-1][c]=Nm_Image[pI]  [qI-1][c]+error*7/16;
                    Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error*3/16;
                    Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error*5/16;
                    Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error*1/16;
                    
                }
            }
        }
        }
    
    ///////////////////Write image/////////////////////
    ofstream ofile("Sailboat_scl.raw",ios_base::out | ios_base::binary);
    if (!ofile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
            for (c=0;c<BytesPerPixel;c++)
            {
                Out_Image[pO][qO][c]=Out_Image[pO][qO][c]+0x00;    //Convert to hex or bin
                ofile.write((char*)&Out_Image[pO][qO][c],sizeof(Out_Image[pO][qO][c]));
            }
    
    
    ofile.close();
    cout<<"The end!"<<endl;
    getchar();
    return 0;
}
