//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (b)
//This code is to capture a scene in the 3D world coordinates system and project it onto a 2D image plane
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

const int BytesPerPixel=3; //24-bit
const int Size_H=200;      //the size of input image
const int Size_W=200;      //the size of input image
const int Win_Size=720;    //the size of output image

int main()
{
    
    
    int    pO=0,qO=0;      //the Image coordinate of output
    int    pI=0,qI=0;      //the Image coordinate of input
    int    c=0;            //channels
    double X,Y,Z;          //the world coordinates
    double x,y;            //the image plane coordinates
    double Xc,Yc,Zc;
    int    xc_O,yc_O;
    
    int    i,j;            //the coodinates of the window controling the density of output
    
    double f;              //the focal length
    double fc=1;           //the coefficient of the focal length
    int fcc;               //control the density of output based on the focal length
    if (fc>1)
        fcc=(int)(fc-1);
    else
        fcc=0;
    f=fc*sqrt(3);
    
    unsigned char RIn_Image   [Size_H][Size_W][BytesPerPixel];          //one of the image data of input images
    unsigned char LIn_Image   [Size_H][Size_W][BytesPerPixel];          //one of the image data of input images
    unsigned char UIn_Image   [Size_H][Size_W][BytesPerPixel];          //one of the image data of input images
    unsigned char Out_Image   [Win_Size][Win_Size][BytesPerPixel]={0};  //the image data of output image
    
    
    ///////////////Read image///////////////
    ifstream ifile_d("baby_dog.raw",ios_base::in | ios_base::binary);
    if (!ifile_d)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
                ifile_d.read((char*)&RIn_Image[pI][qI][c],sizeof(RIn_Image[pI][qI][c]));
    ifile_d.close();
    
    //the image on the right side of the cube
    X=1;
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            //change image coordinates to the world coordinates
            Y= 0.01*qI-0.995;
            Z=-0.01*pI+0.995;
            
            //change the world coordinates to image plane coordinates
            Xc=(1/sqrt(2))*Y-(1/sqrt(2))*X;
            Yc=(1/sqrt(6))*X+(1/sqrt(6))*Y-(2/sqrt(6))*Z;
            Zc=(15/sqrt(3))-(1/sqrt(3))*(X+Y+Z);
    
            x=f*Xc/Zc;
            y=f*Yc/Zc;
            
            x=(-1)*x;
            y=(-1)*y;
            
            xc_O=(int)(x*1000);
            yc_O=(int)(y*1000);
            
            //change the Cartesian coordinates to image coordinates of output
            if (yc_O<0)
                pO=Win_Size/2-yc_O;
            else
                pO=Win_Size/2-1-yc_O;
            
            if (xc_O<0)
                qO=Win_Size/2+xc_O;
            else
                qO=Win_Size/2-1+xc_O;
            
            //control the pixel density of output
            if (pO<Win_Size && pO>=0)
            {
                if (qO<Win_Size && qO>=0)
                {
                    for (c=0;c<BytesPerPixel;c++)
                    {
                        for (i=-1-fcc; i<2+fcc; i++)
                            for (j=-1-fcc; j<2+fcc; j++)
                                Out_Image[pO+i][qO+j][c]=RIn_Image[pI][qI][c];
                        
                    }
                }
            }
            
        }
    
    
    ///////////////Read image///////////////
    ifstream ifile_c("baby_cat.raw",ios_base::in | ios_base::binary);
    if (!ifile_c)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
                ifile_c.read((char*)&LIn_Image[pI][qI][c],sizeof(LIn_Image[pI][qI][c]));
    ifile_c.close();
    
    //the image on the left side of the cube
    Y=1;
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            //change image coordinates to the world coordinates
            X=-0.01*qI+0.995;
            Z=-0.01*pI+0.995;
            
            //change the world coordinates to image plane coordinates
            Xc=(1/sqrt(2))*Y-(1/sqrt(2))*X;
            Yc=(1/sqrt(6))*X+(1/sqrt(6))*Y-(2/sqrt(6))*Z;
            Zc=(15/sqrt(3))-(1/sqrt(3))*(X+Y+Z);
            
            x=f*Xc/Zc;
            y=f*Yc/Zc;
            
            x=(-1)*x;
            y=(-1)*y;
            
            xc_O=(int)(x*1000);
            yc_O=(int)(y*1000);
            
            //change the Cartesian coordinates to image coordinates of output
            if (yc_O<0)
                pO=Win_Size/2-yc_O;
            else
                pO=Win_Size/2-1-yc_O;
            if (xc_O<0)
                qO=Win_Size/2+xc_O;
            else
                qO=Win_Size/2-1+xc_O;
            
            //control the pixel density of output
            if (pO<Win_Size && pO>=0)
            {
                if (qO<Win_Size && qO>=0)
                {
                    for (c=0;c<BytesPerPixel;c++)
                    {
                        for (i=-1-fcc; i<2+fcc; i++)
                            for (j=-1-fcc; j<2+fcc; j++)
                                Out_Image[pO+i][qO+j][c]=LIn_Image[pI][qI][c];
                        
                    }
                }
            }
        }
    
    
    ///////////////Read image///////////////
    ifstream ifile_b("baby_panda.raw",ios_base::in | ios_base::binary);
    if (!ifile_b)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
                ifile_b.read((char*)&UIn_Image[pI][qI][c],sizeof(UIn_Image[pI][qI][c]));
    ifile_b.close();
    
    //the image on the left side of the cube
    Z=1;
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            //change image coordinates to the world coordinates
            Y= 0.01*qI-0.995;
            X= 0.01*pI-0.995;
            
            //change the world coordinates to image plane coordinates
            Xc=(1/sqrt(2))*Y-(1/sqrt(2))*X;
            Yc=(1/sqrt(6))*X+(1/sqrt(6))*Y-(2/sqrt(6))*Z;
            Zc=(15/sqrt(3))-(1/sqrt(3))*(X+Y+Z);
            
            x=f*Xc/Zc;
            y=f*Yc/Zc;
            
            x=(-1)*x;
            y=(-1)*y;
            
            xc_O=(int)(x*1000);
            yc_O=(int)(y*1000);
            
            //change the Cartesian coordinates to image coordinates of output
            if (yc_O<0)
                pO=Win_Size/2-yc_O;
            else
                pO=Win_Size/2-1-yc_O;
            if (xc_O<0)
                qO=Win_Size/2+xc_O;
            else
                qO=Win_Size/2-1+xc_O;
            
            //control the pixel density of output
            if (pO<Win_Size && pO>=0)
            {
                if (qO<Win_Size && qO>=0)
                {
                    for (c=0;c<BytesPerPixel;c++)
                    {
                        for (i=-1-fcc; i<2+fcc; i++)
                            for (j=-1-fcc; j<2+fcc; j++)
                                Out_Image[pO+i][qO+j][c]=UIn_Image[pI][qI][c];
                                //Out_Image[pO+i][qO+j][c]=0;
                        
                    }
                }
            }
        }
    

    
    ///////////////////Write image/////////////////////
    ofstream ofile("2D_image.raw",ios_base::out | ios_base::binary);
    if (!ofile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    for (pO=0;pO<Win_Size;pO++)
        for (qO=0;qO<Win_Size;qO++)
            for (c=3;c<BytesPerPixel+3;c++)
            {
                Out_Image[pO][qO][c]=Out_Image[pO][qO][c]+0x00;    //Convert to hex or bin
                ofile.write((char*)&Out_Image[pO][qO][c],sizeof(Out_Image[pO][qO][c]));
            }
    
    
    
    ofile.close();
    cout<<"The end"<<endl;
    
    getchar();
    return 0;
    
    
}

