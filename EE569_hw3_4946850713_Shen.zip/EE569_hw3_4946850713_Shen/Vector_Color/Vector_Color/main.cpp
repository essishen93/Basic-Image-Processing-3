//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (d)
//This code is to implement vector color halftoning
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
#include "function.h"
using namespace std;

const int Size_H=512;        //the size of input image
const int Size_W=512;    //the size of input image
const int BytesPerPixel=3; //24-bit
const double T=0.5;

//find the closest vertice and compute the error
void get_error(unsigned char quadruple, double C_v, double M_v, double Y_v, double *error);

int  main()
{
    int c=0;          //channels
    int pO=0,qO=0;    //the Image coordinate of output
    int pI=0,qI=0;    //the Image coordinate of input
    
    unsigned char In_Image   [Size_H][Size_W][BytesPerPixel];        //the image data of input image (CMY)
    double        Nm_Image   [Size_H][Size_W][BytesPerPixel];        //the input image with the normalized gray value (0-1) + error
    //double        nml_Image  [Size_H][Size_W][BytesPerPixel];        //the input image with the normalized gray value (0-1)
    unsigned char Quadruple  [Size_H][Size_W]={0};                   //the one of the six quadruples a pixel belongs to
    unsigned char Out_Image  [Size_H][Size_W][BytesPerPixel];        //the image data of output image
    
    
    ///////////////Read image///////////////
    ifstream ifile("Sailboat.raw",ios_base::in | ios_base::binary);
    if (!ifile)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
            {
                ifile.read((char*)&In_Image[pI][qI][c],sizeof(In_Image[pI][qI][c]));
                //In_Image[pI][qI][c]=256-In_Image[pI][qI][c];  //CMY
                
                //Out_Image[pI][qI][c]=In_Image[pI][qI][c];
            }
    
    ////////////Normalization//////////////////
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
            {
                Nm_Image[pI][qI][c] =(double)In_Image[pI][qI][c]/256;
               // nml_Image[pI][qI][c]=(double)In_Image[pI][qI][c]/256;
            }
    
    int C=0,M=0,Y=0;
    double C_v=0,M_v=0,Y_v=0;   //the value of C,M,Y
    double error[3]={0};        //the error in each channel
    //int xx;
    ////////////Find the quadruple//////////////////
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            for (c=0;c<BytesPerPixel;c++)
            {
                if (c==0)
                    C=In_Image[pI][qI][c];
                else if (c==1)
                    M=In_Image[pI][qI][c];
                else
                    Y=In_Image[pI][qI][c];
            }
            
            if ((C+M)>256)
            {
                if ((M+Y)>256)
                {
                    if ((C+M+Y)>512)
                    {
                        Quadruple[pI][qI]=1;   //CMYW
                        //cout<<"1"<<endl;
                    }
                    else
                        Quadruple[pI][qI]=2;   //MYGC
                }
                else
                    Quadruple[pI][qI]=3;       //RGMY
            }
            else
            {
                if (!((M+Y)>256))
                {
                    if (!((C+M+Y)>256))
                        Quadruple[pI][qI]=4;    //KRGB
                    else
                        Quadruple[pI][qI]=5;    //RGBM
                }
                else
                    Quadruple[pI][qI]=6;        //CMGB
            }
            //Quadruple[pI][qI]=xx;
            
        }
   
    
    ///////Vector Color Halftoning///////////
    for (pI=0;pI<Size_H;pI++)
    {
        //the even row
        if (pI%2==0)
        {
            for (qI=0;qI<Size_W;qI++)
            {
                for (c=0;c<BytesPerPixel;c++)
                {
                    pO=pI;qO=qI;
                    
                    if(Nm_Image[pI][qI][c]>T)
                        Out_Image[pO][qO][c]=255;
                    else
                        Out_Image[pO][qO][c]=0;
                    
                    if (c==0)
                        C_v=Nm_Image[pI][qI][c];
                    else if (c==1)
                        M_v=Nm_Image[pI][qI][c];
                    else
                        Y_v=Nm_Image[pI][qI][c];
                }
                //cout<<C_v<<"   "<<M_v<<"   "<<Y_v<<endl;
                //find the closest vertice and compute the error
                get_error(Quadruple[pI][qI], C_v, M_v, Y_v, error);
               
                //cout<<error[0]<<"   "<<error[1]<<"   "<<error[2]<<endl;
                
                //Floyd-Steinberg's error diffusion
                for (c=0;c<BytesPerPixel;c++)
                {
                    if (qI==0)
                    {
                        Nm_Image[pI]  [qI+1][c]=Nm_Image[pI]  [qI+1][c]+error[c]*7/16;
                        
                        Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error[c]*5/16;
                        Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error[c]*1/16;
                    }
                    else if (qI==Size_W-1)
                    {
                        Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error[c]*5/16;
                        Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error[c]*3/16;
                    }
                    else
                    {
                        Nm_Image[pI]  [qI+1][c]=Nm_Image[pI]  [qI+1][c]+error[c]*7/16;
                        Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error[c]*3/16;
                        Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error[c]*5/16;
                        Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error[c]*1/16;
                        
                    }
                }
            }
        }
        
        //the odd row
        else
        {
            for (qI=Size_W-1;qI>=0;qI--)
            {
                for (c=0;c<BytesPerPixel;c++)
                {
                    pO=pI;qO=qI;
                    
                    if(Nm_Image[pI][qI][c]>T)
                        Out_Image[pO][qO][c]=255;
                    else
                        Out_Image[pO][qO][c]=0;
                    
                    if (c==0)
                        C_v=Nm_Image[pI][qI][c];
                    else if (c==1)
                        M_v=Nm_Image[pI][qI][c];
                    else
                        Y_v=Nm_Image[pI][qI][c];
                }
                
                //find the closest vertice and compute the error
                get_error(Quadruple[pI][qI], C_v, M_v, Y_v, error);
                
                //Floyd-Steinberg's error diffusion
                for (c=0;c<BytesPerPixel;c++)
                {
                    if (pI<Size_H-1 && qI==Size_W-1)
                    {
                        Nm_Image[pI]  [qI-1][c]=Nm_Image[pI]  [qI-1][c]+error[c]*7/16;
                        
                        Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error[c]*5/16;
                        Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error[c]*1/16;
                    }
                    else if (pI<Size_H-1 && qI==0)
                    {
                        Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error[c]*5/16;
                        Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error[c]*3/16;
                    }
                    else if (pI==Size_H-1 && qI!=0)
                    {
                        Nm_Image[pI]  [qI-1][c]=Nm_Image[pI]  [qI-1][c]+error[c]*7/16;
                        //Nm_Image[pI][qI][c]=Nm_Image[pI][qI][c];
                    }
                    else if (pI==Size_H-1 && qI==0)
                    {
                        Nm_Image[pI][qI][c]=Nm_Image[pI][qI][c];
                    }
                    else
                    {
                        Nm_Image[pI]  [qI-1][c]=Nm_Image[pI]  [qI-1][c]+error[c]*7/16;
                        Nm_Image[pI+1][qI+1][c]=Nm_Image[pI+1][qI+1][c]+error[c]*3/16;
                        Nm_Image[pI+1][qI]  [c]=Nm_Image[pI+1][qI]  [c]+error[c]*5/16;
                        Nm_Image[pI+1][qI-1][c]=Nm_Image[pI+1][qI-1][c]+error[c]*1/16;
                        
                    }
                }
            }
        }
    }
    
    ///////////////////Write image/////////////////////
    ofstream ofile("Sailboat_vec.raw",ios_base::out | ios_base::binary);
    if (!ofile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
            for (c=0;c<BytesPerPixel;c++)
            {
                Out_Image[pO][qO][c]=Out_Image[pO][qO][c]+0x00;    //Convert to hex or bin
                ofile.write((char*)&Out_Image[pO][qO][c],sizeof(Out_Image[pO][qO][c]));
            }
    
    
    ofile.close();
    cout<<"The end!"<<endl;
    getchar();
    return 0;
}

