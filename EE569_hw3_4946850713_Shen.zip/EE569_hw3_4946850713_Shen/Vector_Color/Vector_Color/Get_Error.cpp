//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (d)
//This code is to implement vector color halftoning
/////////////////////////////////////////////////////////////////////
//Get_Error.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

//The vertices in CMY cube
/*
int vertex[8][3]={{1,0,0},
    {0,1,0},
    {0,0,1},
    {0,1,1},
    {1,0,1},
    {1,1,0},
    {0,0,0},
    {1,1,1}};*/

double vertex[8][3]={{1,0,0},
    {0,1,0},
    {0,0,1},
    {0,1,1},
    {1,0,1},
    {1,1,0},
    {1,1,1},
    {0,0,0}};


void get_error(unsigned char quadruple, double C_v, double M_v, double Y_v, double *error)
{
    int    row=0;
    double min_dis=0,temp_dis=0;
    
    
    

    //find the closest vertice and compute the error
    if (quadruple==1)   //CMYW
    {
        row=3;
        min_dis =sqrt((C_v-vertex[3][0])*(C_v-vertex[3][0])+(M_v-vertex[3][1])*(M_v-vertex[3][1])+(Y_v-vertex[3][2])*(Y_v-vertex[3][2]));
        
        temp_dis=sqrt((C_v-vertex[4][0])*(C_v-vertex[4][0])+(M_v-vertex[4][1])*(M_v-vertex[4][1])+(Y_v-vertex[4][2])*(Y_v-vertex[4][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=4;
        }
        
        
        
        temp_dis=sqrt((C_v-vertex[5][0])*(C_v-vertex[5][0])+(M_v-vertex[5][1])*(M_v-vertex[5][1])+(Y_v-vertex[5][2])*(Y_v-vertex[5][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=5;
        }
        
        temp_dis=sqrt((C_v-vertex[6][0])*(C_v-vertex[6][0])+(M_v-vertex[6][1])*(M_v-vertex[6][1])+(Y_v-vertex[6][2])*(Y_v-vertex[6][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=6;
        }
        
        
    }
    
    if (quadruple==2)   //MYGC
    {
        row=4;
        min_dis =sqrt((C_v-vertex[4][0])*(C_v-vertex[4][0])+(M_v-vertex[4][1])*(M_v-vertex[4][1])+(Y_v-vertex[4][2])*(Y_v-vertex[4][2]));
        
        temp_dis=sqrt((C_v-vertex[5][0])*(C_v-vertex[5][0])+(M_v-vertex[5][1])*(M_v-vertex[5][1])+(Y_v-vertex[5][2])*(Y_v-vertex[5][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=5;
        }
        
        temp_dis=sqrt((C_v-vertex[1][0])*(C_v-vertex[1][0])+(M_v-vertex[1][1])*(M_v-vertex[1][1])+(Y_v-vertex[1][2])*(Y_v-vertex[1][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=1;
        }
        
        temp_dis=sqrt((C_v-vertex[3][0])*(C_v-vertex[3][0])+(M_v-vertex[3][1])*(M_v-vertex[3][1])+(Y_v-vertex[3][2])*(Y_v-vertex[3][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=3;
        }
        
    }
    
    if (quadruple==3)   //RGMY
    {
        row=0;
        min_dis =sqrt((C_v-vertex[0][0])*(C_v-vertex[0][0])+(M_v-vertex[0][1])*(M_v-vertex[0][1])+(Y_v-vertex[0][2])*(Y_v-vertex[0][2]));
        
        temp_dis=sqrt((C_v-vertex[1][0])*(C_v-vertex[1][0])+(M_v-vertex[1][1])*(M_v-vertex[1][1])+(Y_v-vertex[1][2])*(Y_v-vertex[1][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=1;
        }
        
        temp_dis=sqrt((C_v-vertex[4][0])*(C_v-vertex[4][0])+(M_v-vertex[4][1])*(M_v-vertex[4][1])+(Y_v-vertex[4][2])*(Y_v-vertex[4][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=4;
        }
        
        temp_dis=sqrt((C_v-vertex[5][0])*(C_v-vertex[5][0])+(M_v-vertex[5][1])*(M_v-vertex[5][1])+(Y_v-vertex[5][2])*(Y_v-vertex[5][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=5;
        }
        
        
    }
    
    if (quadruple==4)   //KRGB
    {
        row=7;
        min_dis =sqrt((C_v-vertex[7][0])*(C_v-vertex[7][0])+(M_v-vertex[7][1])*(M_v-vertex[7][1])+(Y_v-vertex[7][2])*(Y_v-vertex[7][2]));
        
        temp_dis=sqrt((C_v-vertex[0][0])*(C_v-vertex[0][0])+(M_v-vertex[0][1])*(M_v-vertex[0][1])+(Y_v-vertex[0][2])*(Y_v-vertex[0][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=0;
        }
        
        temp_dis=sqrt((C_v-vertex[1][0])*(C_v-vertex[1][0])+(M_v-vertex[1][1])*(M_v-vertex[1][1])+(Y_v-vertex[1][2])*(Y_v-vertex[1][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=1;
        }
        
        temp_dis=sqrt((C_v-vertex[2][0])*(C_v-vertex[2][0])+(M_v-vertex[2][1])*(M_v-vertex[2][1])+(Y_v-vertex[2][2])*(Y_v-vertex[2][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=2;
        }
        
        
    }
    
    if (quadruple==5)   //RGBM
    {
        row=0;
        min_dis =sqrt((C_v-vertex[0][0])*(C_v-vertex[0][0])+(M_v-vertex[0][1])*(M_v-vertex[0][1])+(Y_v-vertex[0][2])*(Y_v-vertex[0][2]));
        
        temp_dis=sqrt((C_v-vertex[1][0])*(C_v-vertex[1][0])+(M_v-vertex[1][1])*(M_v-vertex[1][1])+(Y_v-vertex[1][2])*(Y_v-vertex[1][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=1;
        }
        
        temp_dis=sqrt((C_v-vertex[2][0])*(C_v-vertex[2][0])+(M_v-vertex[2][1])*(M_v-vertex[2][1])+(Y_v-vertex[2][2])*(Y_v-vertex[2][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=2;
        }
        
        temp_dis=sqrt((C_v-vertex[4][0])*(C_v-vertex[4][0])+(M_v-vertex[4][1])*(M_v-vertex[4][1])+(Y_v-vertex[4][2])*(Y_v-vertex[4][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=4;
        }
        
        
        
    }
    
    if (quadruple==6)   //CMGB
    {
        row=3;
        min_dis =sqrt((C_v-vertex[3][0])*(C_v-vertex[3][0])+(M_v-vertex[3][1])*(M_v-vertex[3][1])+(Y_v-vertex[3][2])*(Y_v-vertex[3][2]));
        
        temp_dis=sqrt((C_v-vertex[4][0])*(C_v-vertex[4][0])+(M_v-vertex[4][1])*(M_v-vertex[4][1])+(Y_v-vertex[4][2])*(Y_v-vertex[4][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=4;
        }
        
        temp_dis=sqrt((C_v-vertex[1][0])*(C_v-vertex[1][0])+(M_v-vertex[1][1])*(M_v-vertex[1][1])+(Y_v-vertex[1][2])*(Y_v-vertex[1][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=1;
        }
        
        temp_dis=sqrt((C_v-vertex[2][0])*(C_v-vertex[2][0])+(M_v-vertex[2][1])*(M_v-vertex[2][1])+(Y_v-vertex[2][2])*(Y_v-vertex[2][2]));
        if (temp_dis<min_dis)
        {
            min_dis=temp_dis;
            row=2;
        }
        
        
        
    }
    
    
    row=0;
    min_dis =sqrt((C_v-vertex[0][0])*(C_v-vertex[0][0])+(M_v-vertex[0][1])*(M_v-vertex[0][1])+(Y_v-vertex[0][2])*(Y_v-vertex[0][2]));
    
    temp_dis=sqrt((C_v-vertex[1][0])*(C_v-vertex[1][0])+(M_v-vertex[1][1])*(M_v-vertex[1][1])+(Y_v-vertex[1][2])*(Y_v-vertex[1][2]));
    if (temp_dis<min_dis)
    {
        min_dis=temp_dis;
        row=1;
    }
    
    temp_dis=sqrt((C_v-vertex[2][0])*(C_v-vertex[2][0])+(M_v-vertex[2][1])*(M_v-vertex[2][1])+(Y_v-vertex[2][2])*(Y_v-vertex[2][2]));
    if (temp_dis<min_dis)
    {
        min_dis=temp_dis;
        row=2;
    }
    
    temp_dis=sqrt((C_v-vertex[3][0])*(C_v-vertex[3][0])+(M_v-vertex[3][1])*(M_v-vertex[3][1])+(Y_v-vertex[3][2])*(Y_v-vertex[3][2]));
    if (temp_dis<min_dis)
    {
        min_dis=temp_dis;
        row=3;
    }
    
    temp_dis=sqrt((C_v-vertex[4][0])*(C_v-vertex[4][0])+(M_v-vertex[4][1])*(M_v-vertex[4][1])+(Y_v-vertex[4][2])*(Y_v-vertex[4][2]));
    if (temp_dis<min_dis)
    {
        min_dis=temp_dis;
        row=4;
    }
    
    temp_dis=sqrt((C_v-vertex[5][0])*(C_v-vertex[5][0])+(M_v-vertex[5][1])*(M_v-vertex[5][1])+(Y_v-vertex[5][2])*(Y_v-vertex[5][2]));
    if (temp_dis<min_dis)
    {
        min_dis=temp_dis;
        row=5;
    }
    
    temp_dis=sqrt((C_v-vertex[6][0])*(C_v-vertex[6][0])+(M_v-vertex[6][1])*(M_v-vertex[6][1])+(Y_v-vertex[6][2])*(Y_v-vertex[6][2]));
    if (temp_dis<min_dis)
    {
        min_dis=temp_dis;
        row=6;
    }
    
    temp_dis=sqrt((C_v-vertex[7][0])*(C_v-vertex[7][0])+(M_v-vertex[7][1])*(M_v-vertex[7][1])+(Y_v-vertex[7][2])*(Y_v-vertex[7][2]));
    if (temp_dis<min_dis)
    {
        min_dis=temp_dis;
        row=7;
    }
    
    error[0]=C_v-vertex[row][0];
    error[1]=M_v-vertex[row][1];
    error[2]=Y_v-vertex[row][2];
    
    
}
