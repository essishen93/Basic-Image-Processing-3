//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 3 : (b)
//This code is to skeletoning the binary image
/////////////////////////////////////////////////////////////////////
//function.h
/////////////////////////////////////////////////////////////////////

#ifndef _FUNCTION_CPP_
#define _FUNCTION_CPP_
using namespace std;

//void get_error(unsigned char quadruple, double C_v, double M_v, double Y_v, double *error);
int get_M(int bone, int value);
int get_G(int value);
#endif
