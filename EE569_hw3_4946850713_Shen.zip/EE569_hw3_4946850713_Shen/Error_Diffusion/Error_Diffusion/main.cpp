//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (b)
//This code is to implement digital halftoning by error diffussion
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

const int Size_H=512;    //the size of input image
const int Size_W=512;    //the size of input image
const double T=0.5;      //the threshold


int  main()
{
    
    int pO=0,qO=0;    //the Image coordinate of output
    int pI=0,qI=0;    //the Image coordinate of input
    
    unsigned char In_Image   [Size_H][Size_W];               //the image data of input image
    double        Nm_Image   [Size_H][Size_W];               //the input image with the normalized gray value (0-1)
    unsigned char Out_ImageF [Size_H][Size_W];               //the image data of output image by 4X4 Bayer matrix
    unsigned char Out_ImageJ [Size_H][Size_W];               //the image data of output image by 8X8 Bayer matrix
    unsigned char Out_ImageS [Size_H][Size_W];               //the image data of output image by 4 gray value(0,85,170,255)

    
    ///////////////Read image///////////////
    ifstream ifile("mandrill.raw",ios_base::in | ios_base::binary);
    if (!ifile)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            ifile.read((char*)&In_Image[pI][qI],sizeof(In_Image[pI][qI]));
    
    ////////////Normalization//////////////////
    int Fmax=0,Fmin=0;  //the maximun and minimum gray value of input
    int temp;
    Fmax=In_Image[0][0];
    Fmin=In_Image[0][0];
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
        {
            temp=In_Image[pI][qI];
            if (temp>Fmax)
                Fmax=temp;
            if (temp<Fmin)
                Fmin=temp;
        }
    
    //Normalization
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            Nm_Image[pI][qI]=(double)In_Image[pI][qI]/256;
    
    double new_value=0;
    double error=0;
    
    ///////Floyd-Steinberg's error diffusion///////////
    for (pI=0;pI<Size_H;pI++)
    {
        //the even row
        if (pI%2==0)
        {
            for (qI=0;qI<Size_W;qI++)
            {
                pO=pI;qO=qI;
                if(Nm_Image[pI][qI]>T)
                {
                    Out_ImageF[pO][qO]=255;
                    new_value=1;
                }
                else
                {
                    Out_ImageF[pO][qO]=0;
                    new_value=0;
                }
                error=Nm_Image[pI][qI]-new_value;
                
            
                //Floyd-Steinberg's error diffusion
                if (qI==0)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*7/16;
                  
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*5/16;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*1/16;
                }
                else if (qI==(Size_W-1))
                {
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*5/16;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*1/16;
                }
                else
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*7/16;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*3/16;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*5/16;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*1/16;
                    
                }
            }
        }
        
        //the odd row
        else
        {
            for (qI=Size_W-1;qI>=0;qI--)
            {
                pO=pI;qO=qI;
                if(Nm_Image[pI][qI]>T)
                {
                    Out_ImageF[pO][qO]=255;
                    new_value=1;
                }
                else
                {
                    Out_ImageF[pO][qO]=0;
                    new_value=0;
                }
                error=Nm_Image[pI][qI]-new_value;
                
                //Floyd-Steinberg's error diffusion
                if (pI<(Size_H-1) && qI==(Size_W-1))
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*7/16;

                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*5/16;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*1/16;
                }
                else if (pI<(Size_H-1) && qI==0)
                {
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*5/16;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*3/16;
                }
                else if (pI==(Size_H-1) && qI!=0)
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*7/16;
                }
                else if (pI==(Size_H-1) && qI==0)
                {
                     Nm_Image[pI][qI]=Nm_Image[pI][qI];
                }
                else
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*7/16;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*3/16;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*5/16;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*1/16;
                    
                }
            }
        }
        
        
    }
    
    //Normalization
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            Nm_Image[pI][qI]=(double)In_Image[pI][qI]/256;
    
    
    //////////JJN error diffusion//////////////
    for (pI=0;pI<Size_H;pI++)
    {
        //the even row
        if (pI%2==0)
        {
            for (qI=0;qI<Size_W;qI++)
            {
                pO=pI;qO=qI;
                if(Nm_Image[pI][qI]>T)
                {
                    Out_ImageJ[pO][qO]=255;
                    new_value=1;
                }
                else
                {
                    Out_ImageJ[pO][qO]=0;
                    new_value=0;
                }
                error=Nm_Image[pI][qI]-new_value;
                
                //JJN error diffusion
                if (pI<Size_H-2 && qI==0)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*7/48;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*5/48;

                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;
                    
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/48;
                }
                else if (pI<Size_H-2 && qI==Size_W-1)
                {
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/48;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                }
                else if (pI<Size_H-2 && qI==1)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*7/48;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*5/48;
                    
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;
                    
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/48;
                }
                else if (pI<Size_H-2 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI+1]  =Nm_Image[pI][qI+1]  +error*7/48;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/48;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;

                }
                
                else if (pI==Size_H-2 && qI==0)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*7/48;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*5/48;
                    
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;

                }
                else if (pI==Size_H-2 && qI==Size_W-1)
                {
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    
                }
                
                
                else if (pI==Size_H-2 && qI==1)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*7/48;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*5/48;
                    
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;

                }
                else if (pI==Size_H-2 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI+1]  =Nm_Image[pI][qI+1]  +error*7/48;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    
                }

                
                else
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*7/48;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*5/48;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/48;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/48;
                }
            }
        }
        
        //the odd row
        else
        {
            for (qI=Size_W-1;qI>=0;qI--)
            {
                pO=pI;qO=qI;
                if(Nm_Image[pI][qI]>T)
                {
                    Out_ImageJ[pO][qO]=255;
                    new_value=1;
                }
                else
                {
                    Out_ImageJ[pO][qO]=0;
                    new_value=0;
                }
                error=Nm_Image[pI][qI]-new_value;
                
                //JJN error diffusion
                if (pI<Size_H-1 && qI==0)
                {
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;
                    
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/48;
                }
                else if (pI<Size_H-1 && qI==Size_W-1)
                {
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*5/48;
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*7/48;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/48;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                }
                
                else if (pI<Size_H-1 && qI==1)
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*7/48;
                    
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;
                    
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/48;
                }
                else if (pI<Size_H-1 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*7/48;
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*5/48;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/48;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;
                    
                }
                
                else if (pI==Size_H-1 && qI==0)
                {
                    Nm_Image[pI][qI]=Nm_Image[pI][qI];
                    
                }
                else if (pI==Size_H-1 && qI==Size_W-1)
                {
                    
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*5/48;
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*7/48;
                    
                }
                
                else if (pI==Size_H-1 && qI==1)
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*7/48;
                    
                }
                else if (pI==Size_H-1 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*5/48;
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*7/48;
                    
                }
                
                
                else
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*7/48;
                    Nm_Image[pI]  [qI-2]=Nm_Image[pI]  [qI-2]+error*5/48;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*3/48;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*5/48;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*7/48;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*5/48;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*3/48;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/48;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*3/48;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*5/48;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*3/48;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/48;
                }
            }
        }
    }
    
    //Normalization
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            Nm_Image[pI][qI]=(double)In_Image[pI][qI]/256;
    
    
    //////////Stucki's error diffusion//////////////
    for (pI=0;pI<Size_H;pI++)
    {
        //the even row
        if (pI%2==0)
        {
            for (qI=0;qI<Size_W;qI++)
            {
                pO=pI;qO=qI;
                if(Nm_Image[pI][qI]>T)
                {
                    Out_ImageS[pO][qO]=255;
                    new_value=1;
                }
                else
                {
                    Out_ImageS[pO][qO]=0;
                    new_value=0;
                }
                error=Nm_Image[pI][qI]-new_value;
                
                //Stucki's error diffusion
                if (pI<Size_H-2 && qI==0)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*8/42;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*4/42;
                    
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/42;
                }
                else if (pI<Size_H-2 && qI==Size_W-1)
                {
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/42;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                }
                else if (pI<Size_H-2 && qI==1)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*8/42;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*4/42;
                    
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/42;
                }
                else if (pI<Size_H-2 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI+1]  =Nm_Image[pI][qI+1]  +error*8/42;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/42;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    
                }
                
                else if (pI==Size_H-2 && qI==0)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*8/42;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*4/42;
                    
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                }
                else if (pI==Size_H-2 && qI==Size_W-1)
                {
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    
                }
                
                
                else if (pI==Size_H-2 && qI==1)
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*8/42;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*4/42;
                    
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                }
                else if (pI==Size_H-2 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI+1]  =Nm_Image[pI][qI+1]  +error*8/42;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    
                }
                
                
                else
                {
                    Nm_Image[pI]  [qI+1]=Nm_Image[pI]  [qI+1]+error*8/42;
                    Nm_Image[pI]  [qI+2]=Nm_Image[pI]  [qI+2]+error*4/42;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/42;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/42;
                }
            }
        }
        
        //the odd row
        else
        {
            for (qI=Size_W-1;qI>=0;qI--)
            {
                pO=pI;qO=qI;
                if(Nm_Image[pI][qI]>T)
                {
                    Out_ImageS[pO][qO]=255;
                    new_value=1;
                }
                else
                {
                    Out_ImageS[pO][qO]=0;
                    new_value=0;
                }
                error=Nm_Image[pI][qI]-new_value;
                
                //Stucki's error diffusion
                if (pI<Size_H-1 && qI==0)
                {
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/42;
                }
                else if (pI<Size_H-1 && qI==Size_W-1)
                {
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*4/42;
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*8/42;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/42;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                }
                
                else if (pI<Size_H-1 && qI==1)
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*8/42;
                    
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/42;
                }
                else if (pI<Size_H-1 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*8/42;
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*4/42;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/42;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    
                }
                
                else if (pI==Size_H-1 && qI==0)
                {
                    Nm_Image[pI][qI]=Nm_Image[pI][qI];
                    
                }
                else if (pI==Size_H-1 && qI==Size_W-1)
                {
                    
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*4/42;
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*8/42;
                    
                }
                
                else if (pI==Size_H-1 && qI==1)
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*8/42;
                    
                }
                else if (pI==Size_H-1 && qI==Size_W-2)
                {
                    Nm_Image[pI][qI-2]  =Nm_Image[pI][qI-2]  +error*4/42;
                    Nm_Image[pI][qI-1]  =Nm_Image[pI][qI-1]  +error*8/42;
                    
                }
                
                
                else
                {
                    Nm_Image[pI]  [qI-1]=Nm_Image[pI]  [qI-1]+error*8/42;
                    Nm_Image[pI]  [qI-2]=Nm_Image[pI]  [qI-2]+error*4/42;
                    
                    Nm_Image[pI+1][qI-2]=Nm_Image[pI+1][qI-2]+error*2/42;
                    Nm_Image[pI+1][qI-1]=Nm_Image[pI+1][qI-1]+error*4/42;
                    Nm_Image[pI+1][qI]  =Nm_Image[pI+1][qI]  +error*8/42;
                    Nm_Image[pI+1][qI+1]=Nm_Image[pI+1][qI+1]+error*4/42;
                    Nm_Image[pI+1][qI+2]=Nm_Image[pI+1][qI+2]+error*2/42;
                    
                    Nm_Image[pI+2][qI-2]=Nm_Image[pI+2][qI-2]+error*1/42;
                    Nm_Image[pI+2][qI-1]=Nm_Image[pI+2][qI-1]+error*2/42;
                    Nm_Image[pI+2][qI]  =Nm_Image[pI+2][qI]  +error*4/42;
                    Nm_Image[pI+2][qI+1]=Nm_Image[pI+2][qI+1]+error*2/42;
                    Nm_Image[pI+2][qI+2]=Nm_Image[pI+2][qI+2]+error*1/42;
                }
            }
        }
    }


    
    ///////////////////Write image/////////////////////
    ofstream ofile_F("mandrill_F.raw",ios_base::out | ios_base::binary);
    if (!ofile_F)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    ofstream ofile_J("mandrill_J.raw",ios_base::out | ios_base::binary);
    if (!ofile_J)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    ofstream ofile_S("mandrill_S.raw",ios_base::out | ios_base::binary);
    if (!ofile_S)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
        {
            Out_ImageF[pO][qO]=Out_ImageF[pO][qO]+0x00;    //Convert to hex or bin
            ofile_F.write((char*)&Out_ImageF[pO][qO],sizeof(Out_ImageF[pO][qO]));
            
            Out_ImageJ[pO][qO]=Out_ImageJ[pO][qO]+0x00;    //Convert to hex or bin
            ofile_J.write((char*)&Out_ImageJ[pO][qO],sizeof(Out_ImageJ[pO][qO]));
            
            Out_ImageS[pO][qO]=Out_ImageS[pO][qO]+0x00;    //Convert to hex or bin
            ofile_S.write((char*)&Out_ImageS[pO][qO],sizeof(Out_ImageS[pO][qO]));
        }
    
    
    ifile.close();
    ofile_F.close();
    ofile_J.close();
    ofile_S.close();
    cout<<"The end!"<<endl;
    getchar();
    return 0;
}
