//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 11/01/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (a)
//This code is to implement the swirl effect of the image
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

const int BytesPerPixel=3; //24-bit
const int Size_H=512;      //the size of input image
const int Size_W=512;      //the size of input image

const int R=1;

int  main()
{
    int pO=0,qO=0;    //the Image coordinate of output
    int pI=0,qI=0;    //the Image coordinate of input
    int c=0;          //channels
    
    unsigned char In_Image   [Size_H][Size_W][BytesPerPixel];               //the image data of input image
    unsigned char En_Image   [Size_H+2*R][Size_W+2*R][BytesPerPixel];       //the enlarged version of input image
    unsigned char CIn_Image  [Size_H+2*R][Size_W+2*R][BytesPerPixel]={0};   //the image data of output image(Cartesian Coordinates)
    unsigned char Out_Image  [Size_H][Size_W][BytesPerPixel]={0};           //the image data of input image

    
    ///////////////Read image///////////////
    ifstream ifile("kate.raw",ios_base::in | ios_base::binary);
    if (!ifile)
    {
        cout<<"File CANNOT open!"<<endl;
        exit(1);
    }
    for (pI=0;pI<Size_H;pI++)
        for (qI=0;qI<Size_W;qI++)
            for (c=0;c<BytesPerPixel;c++)
                ifile.read((char*)&In_Image[pI][qI][c],sizeof(In_Image[pI][qI][c]));
    
   
    
    ////////////////Enlarge the input image////////////////
    //the center 512X512
    int row=0,col=0;
    for (row=0;row<Size_H;row++)
        for (col=0;col<Size_W;col++)
            for (c=0;c<BytesPerPixel;c++)
                En_Image[row+R][col+R][c]=In_Image[row][col][c];
    //upper boundary
    for (row=1;row<R+1;row++)
        for (col=0;col<Size_W;col++)
            for (c=0;c<BytesPerPixel;c++)
                En_Image[R-row][col+R][c]=In_Image[row][col][c];
    //right boundary
    for (row=0;row<Size_H+R;row++)
        for (col=Size_W-1;col<Size_W+R-1;col++)
            for (c=0;c<BytesPerPixel;c++)
                En_Image[row][2*Size_W+2*R-2-col][c]=En_Image[row][col][c];
    //lower boundary
    for (row=Size_H-1;row<Size_H+R-1;row++)
        for (col=R;col<Size_W+2*R;col++)
            for (c=0;c<BytesPerPixel;c++)
                En_Image[2*Size_H+2*R-2-row][col][c]=En_Image[row][col][c];
    //left boundary
    for (int row=0;row<Size_H+2*R;row++)
        for (int col=R+1;col<2*R+1;col++)
            for (c=0;c<BytesPerPixel;c++)
                En_Image[row][2*R-col][c]=En_Image[row][col][c];


   
    int    Cx_O=0,Cy_O=0;    //the Cartesian coordinate of output
    double Cx_I=0,Cy_I=0;    //the Cartesian coordinate of input
    int    x=0,y=0;          //the Cartesian coordinate of the start point of Bilinear Interpolation
    
    
    // Image coordinate to Cartesian coordinate
    for (Cx_O=-Size_W/2+R; Cx_O<=Size_W/2+R; ++Cx_O)
        for (Cy_O=-Size_H/2+R; Cy_O<=Size_H/2+R; ++Cy_O)
            for (c=0; c<BytesPerPixel; c++)
            {
                if (Cx_O!=0 && Cy_O!=0)
                {
                    if (Cy_O>0) pI=Size_H/2+1-Cy_O;
                    else        pI=Size_H/2-Cy_O;
                    
                    if (Cx_O>0) qI=Size_W/2+Cx_O;
                    else        qI=Size_W/2+1+Cx_O;
                    
                    CIn_Image[Cx_O][Cy_O][c]=En_Image[pI][qI][c];
                }
            }
    
    
    /////////////////the Swirl Effect////////////////////////
    
    double pi=3.1415926;            //pi
    double max_theta=pi*128/180;    //the maximum angle of rotation
    double rou_max=sqrt(2*256*256); //the maximum radius of image
    double temp;

    double cf;
    float a,b;                      //coefficients in bilinear interpolation
    double rou=0;                   //radius of the Polar coordinates
    double theta=0;                 //angle  of the Polar coordinates
    
    for (Cx_O=-Size_W/2; Cx_O<=Size_W/2; ++Cx_O)
        for (Cy_O=-Size_H/2; Cy_O<=Size_H/2; ++Cy_O)
        {
            // Cartesian coordinate to Image coordinate of output
            if (Cy_O>0) pO=Size_H/2-Cy_O;
            else        pO=Size_H/2-1-Cy_O;
            
            if (Cx_O>0) qO=Size_W/2-1+Cx_O;
            else        qO=Size_W/2+Cx_O;
        
            for (c=0; c<BytesPerPixel; c++)
            {
                if (Cx_O!=0 && Cy_O!=0)
                {
                    //determine the angle of rotation
                    rou=sqrt(Cx_O*Cx_O+Cy_O*Cy_O);
                    cf=atan(Cy_O/Cx_O);
                    theta=max_theta*rou/rou_max;
                    //theta=max_theta*(rou/rou_max)*(rou/rou_max);
                    
                    //Rotation
                    Cx_I=cos(theta)*Cx_O+sin(theta)*Cy_O;
                    Cy_I=-sin(theta)*Cx_O+cos(theta)*Cy_O;
                    
                    //find the Cartesian coordinate of the start point of Bilinear Interpolation
                    if (Cx_I>0)
                        x=(int)(Cx_I*1);
                    else
                        x=(int)(Cx_I*1)-1;
                    if (Cy_I>0)
                        y=(int)(Cy_I*1);
                    else
                        y=(int)(Cy_I*1)-1;
                    
                    
                    //If it is within the image
                    if (x>-Size_W/2-1 && x<Size_W/2+1)
                    {
                        if (y>-Size_H/2-1 && y<Size_H/2+1)
                        {
                            a=Cx_I-x;
                            b=Cy_I-y;
                            // Cartesian coordinate to Image coordinate of the start point of Bilinear Interpolation
                            if (y>0) pI=Size_H/2+1-y;
                            else     pI=Size_H/2-y;
                            
                            if (x>0) qI=Size_W/2+x;
                            else     qI=Size_W/2+1+x;
                            
                            //Bilinear Interpolation
                            temp=(1-a)*(1-b)*En_Image[pI][qI][c]+
                                 (1-a)*b*En_Image[pI-1][qI][c]+
                                 a*(1-b)*En_Image[pI][qI+1][c]+
                                 a*b*En_Image[pI-1][qI+1][c];
                            Out_Image[pO][qO][c]=(unsigned char)temp;
                        }
                        else Out_Image[pO][qO][c]=255;
                    }
                    else Out_Image[pO][qO][c]=255;
                }
            }
        }
    
    ///////////////////Write image/////////////////////
    ofstream ofile("kate_swirl.raw",ios_base::out | ios_base::binary);
    if (!ofile)
    {
        cout<<"open failed"<<endl;
        exit(1);	
    }
    for (pO=0;pO<Size_H;pO++)
        for (qO=0;qO<Size_W;qO++)
            for (c=3;c<BytesPerPixel+3;c++)
            {
                Out_Image[pO][qO][c]=Out_Image[pO][qO][c]+0x00;    //Convert to hex or bin
                ofile.write((char*)&Out_Image[pO][qO][c],sizeof(Out_Image[pO][qO][c]));
            }
    ifile.close();
    ofile.close();
    cout<<"The end"<<endl;
    getchar();
    return 0 ;
    
}
